# Coffee Shop SQL Server Database

Bộ file SQL mẫu để quản lý quán cà phê.

## Files
- schema.sql: tạo database & bảng
- sample_data.sql: dữ liệu demo

## Hướng dẫn chạy
1. Mở SQL Server Management Studio (SSMS).
2. Chạy `schema.sql`.
3. Chạy `sample_data.sql`.
4. Kiểm tra dữ liệu: `SELECT * FROM Product; SELECT * FROM [Order];`
