-- schema.sql
SET NOCOUNT ON;
GO
IF DB_ID('CoffeeShopDB') IS NULL
BEGIN
    CREATE DATABASE CoffeeShopDB;
END
GO
USE CoffeeShopDB;
GO
CREATE TABLE Category (
    CategoryId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(250) NULL
);
GO
CREATE TABLE Product (
    ProductId INT IDENTITY(1,1) PRIMARY KEY,
    CategoryId INT NOT NULL,
    Name NVARCHAR(150) NOT NULL,
    Price DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
    Cost DECIMAL(10,2) NULL,
    Unit NVARCHAR(50) DEFAULT 'pcs',
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Product_Category FOREIGN KEY (CategoryId) REFERENCES Category(CategoryId)
);
GO
CREATE TABLE [CafeTable] (
    TableId INT IDENTITY(1,1) PRIMARY KEY,
    TableName NVARCHAR(50) NOT NULL,
    Seats INT DEFAULT 4,
    IsAvailable BIT DEFAULT 1
);
GO
CREATE TABLE Employee (
    EmployeeId INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(150) NOT NULL,
    Role NVARCHAR(50) NULL,
    Phone NVARCHAR(30) NULL,
    Email NVARCHAR(150) NULL,
    IsActive BIT DEFAULT 1,
    HiredDate DATE DEFAULT CAST(GETDATE() AS DATE)
);
GO
CREATE TABLE Customer (
    CustomerId INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(150) NULL,
    Phone NVARCHAR(30) NULL,
    Email NVARCHAR(150) NULL,
    CreatedAt DATETIME2 DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE [Order] (
    OrderId INT IDENTITY(1,1) PRIMARY KEY,
    OrderNumber NVARCHAR(50) NOT NULL UNIQUE,
    TableId INT NULL,
    EmployeeId INT NULL,
    CustomerId INT NULL,
    OrderStatus NVARCHAR(30) DEFAULT 'Open',
    OrderDate DATETIME2 DEFAULT SYSUTCDATETIME(),
    Total DECIMAL(12,2) DEFAULT 0,
    PaidAmount DECIMAL(12,2) DEFAULT 0,
    CONSTRAINT FK_Order_Table FOREIGN KEY (TableId) REFERENCES CafeTable(TableId),
    CONSTRAINT FK_Order_Employee FOREIGN KEY (EmployeeId) REFERENCES Employee(EmployeeId),
    CONSTRAINT FK_Order_Customer FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerId)
);
GO
CREATE TABLE OrderItem (
    OrderItemId INT IDENTITY(1,1) PRIMARY KEY,
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Quantity INT NOT NULL CHECK (Quantity > 0),
    UnitPrice DECIMAL(10,2) NOT NULL,
    SubTotal AS (Quantity * UnitPrice) PERSISTED,
    CONSTRAINT FK_OrderItem_Order FOREIGN KEY (OrderId) REFERENCES [Order](OrderId) ON DELETE CASCADE,
    CONSTRAINT FK_OrderItem_Product FOREIGN KEY (ProductId) REFERENCES Product(ProductId)
);
GO
CREATE INDEX IX_Product_Name ON Product(Name);
CREATE INDEX IX_Order_OrderDate ON [Order](OrderDate);
GO
