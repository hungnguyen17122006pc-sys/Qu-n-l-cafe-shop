-- sample_data.sql
USE CoffeeShopDB;
GO
INSERT INTO Category (Name, Description) VALUES
(N'Coffee', N'Cà phê nóng & lạnh'),
(N'Tea', N'Trà và đồ uống khác'),
(N'Food', N'Bánh & đồ ăn nhẹ');
INSERT INTO Product (CategoryId, Name, Price, Cost, Unit) VALUES
(1, N'Latte', 40.00, 12.00, 'cup'),
(1, N'Espresso', 30.00, 8.00, 'shot'),
(1, N'Cappuccino', 42.00, 13.00, 'cup'),
(2, N'Tea Lemon', 30.00, 6.00, 'cup'),
(3, N'Cheese Cake', 55.00, 20.00, 'slice');
INSERT INTO CafeTable (TableName, Seats, IsAvailable) VALUES
(N'Table 1', 4, 1),
(N'Table 2', 4, 1),
(N'Table 3', 2, 1);
INSERT INTO Employee (FullName, Role, Phone, Email) VALUES
(N'Nguyễn Văn A', N'Barista', '0123456789', 'a@example.com'),
(N'Trần Thị B', N'Server', '0987654321', 'b@example.com');
DECLARE @ordId INT;
INSERT INTO [Order] (OrderNumber, TableId, EmployeeId, OrderStatus)
VALUES ('ORD-20250801-001', 1, 1, 'Open');
SET @ordId = SCOPE_IDENTITY();
INSERT INTO OrderItem (OrderId, ProductId, Quantity, UnitPrice)
VALUES (@ordId, 1, 2, 40.00), (@ordId, 5, 1, 55.00);
UPDATE [Order]
SET Total = (SELECT ISNULL(SUM(SubTotal),0) FROM OrderItem WHERE OrderId = @ordId)
WHERE OrderId = @ordId;
GO
